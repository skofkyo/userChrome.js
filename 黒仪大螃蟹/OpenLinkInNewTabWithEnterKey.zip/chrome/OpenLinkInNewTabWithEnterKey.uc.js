try {
	if (location.href == 'chrome://browser/content/browser.xul') {
		str = gURLBar.handleCommand.toString();
		str = str.replace('&& !isTabEmpty', '|| isTabEmpty');
		str = str.replace('|| altEnter', '|| !altEnter');
		eval('gURLBar.handleCommand = ' + str);
	}
} catch(e) {}